<?php
namespace dynoser\Hooks;

class Hook extends HookBase
{    
    use \dynoser\Hooks\HookLog;
    use \dynoser\Hooks\HookInt;
    use \dynoser\Hooks\HookNext;
    //use \Solomono\Hooks\HookDepend;
}
