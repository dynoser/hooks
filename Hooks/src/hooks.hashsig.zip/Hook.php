<?php
namespace dynoser\Hooks;

class Hook extends HookBase
{    
    use HookLog;
    use HookNext;
    use HookInt;
    //use \Solomono\Hooks\HookDepend;
}
